module.exports = function(eleventyConfig) {
  // copy admin and static assets
  eleventyConfig.addPassthroughCopy("admin");
  eleventyConfig.addPassthroughCopy("static");
  return {
    dir: {
      input: ".",
      output: "_site"
    }
  };
};
